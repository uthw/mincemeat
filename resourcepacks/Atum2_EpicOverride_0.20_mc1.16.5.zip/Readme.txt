======
ReadMe
======

Resource pack for Atum2 Mod to enable custom entity registration in Epic Fight Mod. This pack provides texture override for Atum2 entities, basically this is experimental. I've used the Zombies and Skeleton model supported by Epic Fight to give animation to the entities of Atum2.


Make sure to download the config file for Atum2 first before applying this resource pack.