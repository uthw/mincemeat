See below which version suits what you are looking for.  

- The Vanilla version just reskins the elytra, so just install the pack to get the custom texture.  

- The Optifine version will only show the texture when an elytra is named "Elysian Tracers" at an anvil. 
It is not case sensitive, and more text can be added on to the end. (eg. "Elysian Tracers abcd" would also work)

I think it goes without saying, but the Optifine version requires Optifine.