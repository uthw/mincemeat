# Unity-Dark
Unity dark theme.

Photoshop action file can be downloaded [here](https://www.dropbox.com/s/ggz5aveq0vdixvz/Unity%20Dark%20Mode.atn?dl=0).
